<?php include 'send.php' ?>

        <!-- Created By Leotrim -->
        <section class="get_in_touch my-5">
            <div class="container">
                <div class="contact-form row">
                    <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
                        <div class="form-field  col-9">
                            <input type="text" name="name" id="name" class="input-text" placeholder="Name" required>
                        </div>
                        <div class="form-field col-lg-6">
                            <input type="email" name="email" id="email" class="input-text" placeholder="Email" required>
                        </div>
                        <div class="field input">
                            <textarea cols="30" rows="5" class="form-control textarea" name="message" required
                                placeholder="Compose your message.."></textarea>
                        </div>
                        <div class="form-field col-lg-12">
                            <input type="submit" name="send" class="submit-btn btn btn-dark text-center"
                                value="Send Message">
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </div>

    <!-- End Contact-->
