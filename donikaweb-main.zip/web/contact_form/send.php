<?php
use PHPMailer\PHPMailer\PHPMailer;

require_once 'phpmailer/src/Exception.php';
require_once 'phpmailer/src/PHPMailer.php';
require_once 'phpmailer/src/SMTP.php';

$mail = new PHPMailer(true);

$alert = '';


if(isset($_POST['send'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];




    try{
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'leotrimthaqi605@gmail.com';  // Your Email   
        $mail->Password = 'kvoftbhafsalszfh';  // to earn this pass you must have 2-Step Verification
        $mail->SMTPSecure = 'tls';
        $mail->Port = '587';

        $mail->setFrom('leotrimthaqi605@gmail.com');

        $mail->addAddress('leotrimthaqi605@gmail.com');

        $mail->isHTML(true);

        $mail->Subject = 'Message Received from the Portfolio : '.  $email;
        $mail->Body = "Emri: $name <br />Email: $email <br /> Message: $message";

        $mail->send();


    } catch (Exception $e) {
        $alert = "<div class='alert-error'><span>'.$e->getMessage().'</span></div>";
    }
    

}
?>
